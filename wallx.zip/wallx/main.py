import cv2
from FindingBalloons import findBalloons,findContours
from DetectHit import detectHit, showBalloons, findBallInBalloon
import pickle
from calibration import WarpImage
points=pickle.load(open("calibration_data.pkl","rb"))

def main1():
    img=cv2.imread("balloonball.png") 
    img1= findBalloons(img)
    img1=cv2.resize(img1,(0,0),None,0.5,0.5)
    imgContours,bboxs= findContours(img1)
    cv2.waitKey(0) 
    cv2.destroyAllWindows()

    # bboxs=[]
    img2=cv2.resize(img,(0,0),None,0.5,0.5)
    cropped_images = detectHit(img2, bboxs)
    #showBalloons(cropped_images)   
    #findBallInBalloon(cropped_images)
    return cropped_images
main1()

# cap = cv2.VideoCapture(r"C:\Users\HP\Downloads\tttt.mp4") 
  
# # Check if camera opened successfully 
# if (cap.isOpened()== False): 
#     print("Error opening video file") 
  
# # Read until video is completed 
# while(cap.isOpened()): 
      
# # Capture frame-by-frame 
#     ret, img = cap.read() 
#     if ret == True: 
#     # Display the resulting frame 
#         img1= findBalloons(img)
#         img1=cv2.resize(img1,(0,0),None,0.5,0.5)
#         imgContours,bboxs= findContours(img1)
#         img2=cv2.resize(img,(0,0),None,0.5,0.5)
#         cropped_images = detectHit(img2, bboxs)
#         print(cropped_images)
#         if cv2.waitKey(25) & 0xFF == ord('q'): 
#           break
  
# # Break the loop 
#     else: 
#         break
# cap.release()
# cv2.destroyAllWindows()'''
 
